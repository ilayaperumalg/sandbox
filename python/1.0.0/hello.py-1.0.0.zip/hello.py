#!/usr/bin/python

import time

# some python code that I want
# to keep on running


# Is this the right way to run the python program forever?
# And do I even need this time.sleep call?
while True:
    time.sleep(5)
    print "Hello!"
